<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head class="animated">
    <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11" />
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
    <?php wp_head(); ?>
    <link href="https://www.intuisyz.com/css/main.css" type="text/css" rel="stylesheet">
    <link href="https://www.intuisyz.com/col/css/bootstrap-3.1.1.min.css" type="text/css" rel="stylesheet">
    <!-- fonts -->
    <link rel="stylesheet" href="https://www.intuisyz.com/fonts/css/font-awesome.css">
    <link rel="stylesheet" href="https://www.intuisyz.com/fonts/css/font-awesome.min.css">
   
   <link rel="shortcut icon" href="https://www.intuisyz.com/n_images/favlogo.png">
</head>

<div class="mt-outer-wrap">
<?php include_once('../header_home.php') ?>
    <div style="height: 40px; width: 100%;clear: both "></div>
<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Vilva
 */
    /**
     * Doctype Hook
     * 
     * @hooked vilva_doctype
    */
    do_action( 'vilva_doctype' );
?>
<head itemscope itemtype="http://schema.org/WebSite">
	<?php 
    /**
     * Before wp_head
     * 
     * @hooked vilva_head
    */
    do_action( 'vilva_before_wp_head' );
    
    wp_head(); ?>
</head>

<body <?php body_class(); ?> itemscope itemtype="http://schema.org/WebPage">

<?php
    wp_body_open();
    
    /**
     * Before Header
     * 
     * @hooked vilva_page_start - 20 
    */
    do_action( 'vilva_before_header' );
    
    /**
     * Header
     * 
     * @hooked vilva_header           - 20     
    */
    do_action( 'vilva_header' );
    
    /**
     * Before Content
     * 
     * @hooked vilva_banner             - 15
     * @hooked vilva_featured_area      - 20
     * @hooked vilva_top_bar            - 30
    */
    do_action( 'vilva_after_header' );
    
    /**
     * Content
     * 
     * @hooked vilva_content_start
    */
    do_action( 'vilva_content' );