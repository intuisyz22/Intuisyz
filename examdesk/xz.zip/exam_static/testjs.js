// jQuery(function ($) {
//     // $(window).bind("beforeunload", function (event) {
//     //     return "Are You Sure ?? ";
//     // });

// });
$(document).ready(function () {


alert("hiii");

    //on load
    // hideDiv();


    // //on resize
    // $(window).resize(function () {
    //     hideDiv();


    // });

});

