<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8">


    <title>
        GST Centre Exam Portal
    </title>


    <meta name="description"
          content="FreshBooks is the #1 invoicing software for small business. Easily send invoices, track time, manage expenses, and get paid online. Start for free today!'"/>

    <meta name="viewport" content="initial-scale=1">


    <script src="../asset/js/jquery-2.1.1.8.js"></script>

<script type="text/javascript">
  $( document ).ready(function() {
    alert("hiii");
});
</script>
    


</head>

<body class="responsive-page">
hello
<script type="text/javascript" src="testjs.js"></script>
</body>


</html>
