// $(document).ready(function () {
//     alert("document ready nnn");

// });
$( "#your_email" ).keyup(function() {
    email=$(this).val();
  $.ajax({
        type:"POST",
        url:base_url+'/user/userAction.php',
        data:{
            type : 'checkUniqMail',
            email : email
        },     
        dataType: "html",
        success: function(response){
            // alert(response);
            if(response!=0){
                alert(email+": Already Exists");
                $( "#your_email" ).val('');
            }
        },
        error (data) {
            alert(data.status);
        }

    });
});