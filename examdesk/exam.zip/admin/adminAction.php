<?php  

include_once('adminFunction.php');
// header('Access-Control-Allow-Origin: *');
       
    $adminObj = new AdminFunction();

if($_SERVER["REQUEST_METHOD"] == "POST"){


///////////////////////////Candidate Rank///////////////////////////////////
	if($_POST['type'] == "getCandidate_rank"){ 
        $result = $adminObj->getCandidate_rank();
        echo json_encode($result);
    }
    elseif($_POST['type'] == "getAllQuestions"){ 
        $result = $adminObj->getAllQuestions();
        // print_r($result);exit;
        echo json_encode($result);
    }elseif($_POST['type'] == "saveQuestion"){ 
        $result = $adminObj->saveQuestions($_POST);
        if($_POST['q_id']!=""){
            header("location:question_view.php");
        }else{
            header('Location: '.BASE_URL.'admin/question.php');
            echo `<html><script type="text/javascript">alert(`.$result['msg'].`);window.location.href="`.BASE_URL.`admin/question.php";</script></html>`;
        }
    }elseif($_POST['type'] == "question4edit"){ 
        $result = $adminObj->question4edit($_POST['q_id']);
        echo json_encode($result);
    }elseif($_POST['type'] == "questionstatus"){ 
        $result = $adminObj->questionstatus($_POST['q_id'],$_POST['cur_status'],$_POST['mark']);
        echo json_encode($result);
    }
    elseif($_POST['type'] == "logout"){ 
        // echo "logout";exit;
        $result=$adminObj->logout();
        echo $result;
    }
    elseif($_POST['type'] == "viewResult"){ 
        $result = $adminObj->view_resultRank($_POST['rankid'],$_POST['qpaper_ID']);
        echo json_encode($result);
    }
///////////////////////////Candidate Rank END///////////////////////////////////


}  
?>  