$(document).ready(function () {
    alert("hiii");
    q_id=$.urlParam('id');
    alert(q_id);
});