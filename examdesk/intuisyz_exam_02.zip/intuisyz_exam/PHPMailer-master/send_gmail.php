<?php
include('PHPMailerAutoload.php');  
$mail = new PHPMailer(); // create a new object
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
$mail->Host = "smtp.gmail.com";
$mail->Port = 465; // or 587
$mail->IsHTML(true);
$mail->Username = "tecotalk1@gmail.com";
$mail->Password = "V+0Bk-kL0U(W";
$mail->SetFrom("tecotalk1@gmail.com");
$mail->Subject = "Test";
$mail->Body = "hello";
$mail->AddAddress("intuisyz.sreejith@gmail.com");

 if(!$mail->Send()) {
    "Mailer Error: " . $mail->ErrorInfo;
 } else {
    echo "Message has been sent";
 }
?>